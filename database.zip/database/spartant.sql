-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2020 at 10:27 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spartant`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `a_id` int(11) NOT NULL,
  `a_name` varchar(50) NOT NULL,
  `a_email` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`a_id`, `a_name`, `a_email`, `password`, `status`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_batch`
--

CREATE TABLE `tbl_batch` (
  `b_id` int(11) NOT NULL,
  `stime` varchar(10) NOT NULL,
  `etime` varchar(10) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_batch`
--

INSERT INTO `tbl_batch` (`b_id`, `stime`, `etime`, `status`) VALUES
(1, '06:00 AM', '08:00 AM', 'yes'),
(2, '07:00 AM', '08:00 AM', 'yes'),
(3, '09:00 AM', '10:00 AM', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `f_id` int(11) NOT NULL,
  `m_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `message` varchar(250) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_feedback`
--

INSERT INTO `tbl_feedback` (`f_id`, `m_id`, `type`, `message`, `status`) VALUES
(1, 1, 'trainer', 'the trainer is very good and always support', 'yes'),
(2, 1, 'gym', 'the gym is very good condition and all equipment are fine to use.', 'yes'),
(3, 4, 'gym', 'jhhhhh', 'yes'),
(4, 4, 'trainer', 'kljhgfd', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `m_id` int(11) NOT NULL,
  `b_id` int(11) NOT NULL,
  `m_name` varchar(50) DEFAULT NULL,
  `m_email` varchar(50) DEFAULT NULL,
  `m_mobile` varchar(20) DEFAULT NULL,
  `m_emobile` varchar(20) DEFAULT NULL,
  `m_height` varchar(10) DEFAULT NULL,
  `m_weight` varchar(10) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `m_ttype` varchar(10) DEFAULT NULL,
  `m_gender` varchar(7) DEFAULT NULL,
  `m_dob` date DEFAULT NULL,
  `m_address` varchar(200) DEFAULT NULL,
  `m_image` varchar(200) NOT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`m_id`, `b_id`, `m_name`, `m_email`, `m_mobile`, `m_emobile`, `m_height`, `m_weight`, `password`, `m_ttype`, `m_gender`, `m_dob`, `m_address`, `m_image`, `status`) VALUES
(1, 1, 'test', 'test1@gmail.com', '9876543212', '9876543212', '153', '54', 'Test@1234', 'personal', 'male', '2020-04-27', 'bardoli', 'image/person_3.jpg', 'yes'),
(2, 1, 'test1', 'test2@gmail.com', '9876543212', '9876543212', '88', '54', 'test123', 'Regular', 'male', '2020-04-13', 'billimora', 'image/person_4.jpg', 'yes'),
(3, 2, 'hari patel', 'test3@gmail.com', '9876543212', '9876543234', '153', '45', 'Test@1234', 'Regular', 'male', '2020-04-13', 'navsari', 'image/person_1.jpg', 'yes'),
(4, 2, 'mukesh', 'ms@gmail.com', '9876543212', '4567890765', '123', '56', 'Mukesh@123', 'personal', 'male', '2020-04-02', 'valsad', 'image/trainer-6.jpg', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `p_id` int(11) NOT NULL,
  `m_id` int(11) NOT NULL,
  `p_months` varchar(20) NOT NULL,
  `p_amount` int(5) DEFAULT NULL,
  `p_date` date NOT NULL,
  `payment` varchar(20) NOT NULL,
  `p_status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`p_id`, `m_id`, `p_months`, `p_amount`, `p_date`, `payment`, `p_status`) VALUES
(1, 1, '1', 600, '2020-04-07', 'accepted', 'yes'),
(2, 4, '3', 1500, '2020-04-08', 'accepted', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trainer`
--

CREATE TABLE `tbl_trainer` (
  `t_id` int(11) NOT NULL,
  `t_name` varchar(50) DEFAULT NULL,
  `t_mobile` bigint(10) DEFAULT NULL,
  `t_email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `t_exp` varchar(20) DEFAULT NULL,
  `t_image` varchar(200) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_trainer`
--

INSERT INTO `tbl_trainer` (`t_id`, `t_name`, `t_mobile`, `t_email`, `password`, `t_exp`, `t_image`, `status`) VALUES
(1, 'trainer', 9876543210, 'trainer@gmail.com', 'trainer@123', '5 year', 'images/trainer-1.jpg', 'yes'),
(2, 'Trainer2', 9876543212, 'trainer2@gmail.com', 'trainer123', '4 years', 'image/trainer-2.jpg', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trainerallocation`
--

CREATE TABLE `tbl_trainerallocation` (
  `ta_id` int(11) NOT NULL,
  `t_id` int(11) NOT NULL,
  `m_id` int(11) NOT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_trainerallocation`
--

INSERT INTO `tbl_trainerallocation` (`ta_id`, `t_id`, `m_id`, `status`) VALUES
(1, 2, 1, 'yes'),
(2, 2, 4, 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `tbl_batch`
--
ALTER TABLE `tbl_batch`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `m_id` (`m_id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `b_id` (`b_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `m_id` (`m_id`);

--
-- Indexes for table `tbl_trainer`
--
ALTER TABLE `tbl_trainer`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `tbl_trainerallocation`
--
ALTER TABLE `tbl_trainerallocation`
  ADD PRIMARY KEY (`ta_id`),
  ADD KEY `t_id` (`t_id`),
  ADD KEY `m_id` (`m_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD CONSTRAINT `tbl_feedback_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `tbl_member` (`m_id`);

--
-- Constraints for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD CONSTRAINT `tbl_member_ibfk_1` FOREIGN KEY (`b_id`) REFERENCES `tbl_batch` (`b_id`);

--
-- Constraints for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD CONSTRAINT `tbl_payment_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `tbl_member` (`m_id`);

--
-- Constraints for table `tbl_trainerallocation`
--
ALTER TABLE `tbl_trainerallocation`
  ADD CONSTRAINT `tbl_trainerallocation_ibfk_1` FOREIGN KEY (`t_id`) REFERENCES `tbl_trainer` (`t_id`),
  ADD CONSTRAINT `tbl_trainerallocation_ibfk_2` FOREIGN KEY (`m_id`) REFERENCES `tbl_member` (`m_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
